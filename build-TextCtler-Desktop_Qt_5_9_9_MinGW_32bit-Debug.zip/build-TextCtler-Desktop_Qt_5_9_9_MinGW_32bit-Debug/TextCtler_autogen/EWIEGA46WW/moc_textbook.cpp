/****************************************************************************
** Meta object code from reading C++ file 'textbook.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.9)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../TextCtler/textbook.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'textbook.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.9. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_TextBook_t {
    QByteArrayData data[14];
    char stringdata0[249];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_TextBook_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_TextBook_t qt_meta_stringdata_TextBook = {
    {
QT_MOC_LITERAL(0, 0, 8), // "TextBook"
QT_MOC_LITERAL(1, 9, 7), // "SendMsg"
QT_MOC_LITERAL(2, 17, 0), // ""
QT_MOC_LITERAL(3, 18, 17), // "on_Weight_clicked"
QT_MOC_LITERAL(4, 36, 7), // "checked"
QT_MOC_LITERAL(5, 44, 17), // "on_Italic_clicked"
QT_MOC_LITERAL(6, 62, 20), // "on_underLine_clicked"
QT_MOC_LITERAL(7, 83, 26), // "on_FortGroundColor_clicked"
QT_MOC_LITERAL(8, 110, 26), // "on_BackGroundColor_clicked"
QT_MOC_LITERAL(9, 137, 27), // "on_lineEdit_editingFinished"
QT_MOC_LITERAL(10, 165, 36), // "on_textEdit_currentCharFormat..."
QT_MOC_LITERAL(11, 202, 15), // "QTextCharFormat"
QT_MOC_LITERAL(12, 218, 6), // "format"
QT_MOC_LITERAL(13, 225, 23) // "on_textEdit_textChanged"

    },
    "TextBook\0SendMsg\0\0on_Weight_clicked\0"
    "checked\0on_Italic_clicked\0"
    "on_underLine_clicked\0on_FortGroundColor_clicked\0"
    "on_BackGroundColor_clicked\0"
    "on_lineEdit_editingFinished\0"
    "on_textEdit_currentCharFormatChanged\0"
    "QTextCharFormat\0format\0on_textEdit_textChanged"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_TextBook[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       9,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   59,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       3,    1,   60,    2, 0x08 /* Private */,
       5,    1,   63,    2, 0x08 /* Private */,
       6,    1,   66,    2, 0x08 /* Private */,
       7,    0,   69,    2, 0x08 /* Private */,
       8,    0,   70,    2, 0x08 /* Private */,
       9,    0,   71,    2, 0x08 /* Private */,
      10,    1,   72,    2, 0x08 /* Private */,
      13,    0,   75,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, QMetaType::Bool,    4,
    QMetaType::Void, QMetaType::Bool,    4,
    QMetaType::Void, QMetaType::Bool,    4,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 11,   12,
    QMetaType::Void,

       0        // eod
};

void TextBook::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        TextBook *_t = static_cast<TextBook *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->SendMsg(); break;
        case 1: _t->on_Weight_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 2: _t->on_Italic_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 3: _t->on_underLine_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 4: _t->on_FortGroundColor_clicked(); break;
        case 5: _t->on_BackGroundColor_clicked(); break;
        case 6: _t->on_lineEdit_editingFinished(); break;
        case 7: _t->on_textEdit_currentCharFormatChanged((*reinterpret_cast< const QTextCharFormat(*)>(_a[1]))); break;
        case 8: _t->on_textEdit_textChanged(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            typedef void (TextBook::*_t)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&TextBook::SendMsg)) {
                *result = 0;
                return;
            }
        }
    }
}

const QMetaObject TextBook::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_TextBook.data,
      qt_meta_data_TextBook,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *TextBook::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *TextBook::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_TextBook.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int TextBook::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 9)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 9;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 9)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 9;
    }
    return _id;
}

// SIGNAL 0
void TextBook::SendMsg()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
