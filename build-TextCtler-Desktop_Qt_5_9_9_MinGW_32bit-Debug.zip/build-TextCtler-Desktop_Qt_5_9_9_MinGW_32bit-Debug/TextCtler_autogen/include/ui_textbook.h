/********************************************************************************
** Form generated from reading UI file 'textbook.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TEXTBOOK_H
#define UI_TEXTBOOK_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QFontComboBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_TextBook
{
public:
    QPushButton *Weight;
    QPushButton *Italic;
    QPushButton *underLine;
    QPushButton *FortGroundColor;
    QPushButton *BackGroundColor;
    QLabel *LB_FontSize;
    QLabel *LB_Font;
    QLineEdit *lineEdit;
    QFontComboBox *fontComboBox;
    QTextEdit *textEdit;

    void setupUi(QWidget *TextBook)
    {
        if (TextBook->objectName().isEmpty())
            TextBook->setObjectName(QStringLiteral("TextBook"));
        TextBook->resize(451, 341);
        Weight = new QPushButton(TextBook);
        Weight->setObjectName(QStringLiteral("Weight"));
        Weight->setGeometry(QRect(10, 10, 75, 23));
        Italic = new QPushButton(TextBook);
        Italic->setObjectName(QStringLiteral("Italic"));
        Italic->setGeometry(QRect(100, 10, 75, 23));
        underLine = new QPushButton(TextBook);
        underLine->setObjectName(QStringLiteral("underLine"));
        underLine->setGeometry(QRect(190, 10, 75, 23));
        FortGroundColor = new QPushButton(TextBook);
        FortGroundColor->setObjectName(QStringLiteral("FortGroundColor"));
        FortGroundColor->setGeometry(QRect(280, 10, 75, 23));
        BackGroundColor = new QPushButton(TextBook);
        BackGroundColor->setObjectName(QStringLiteral("BackGroundColor"));
        BackGroundColor->setGeometry(QRect(370, 10, 75, 23));
        LB_FontSize = new QLabel(TextBook);
        LB_FontSize->setObjectName(QStringLiteral("LB_FontSize"));
        LB_FontSize->setGeometry(QRect(10, 60, 54, 12));
        LB_Font = new QLabel(TextBook);
        LB_Font->setObjectName(QStringLiteral("LB_Font"));
        LB_Font->setGeometry(QRect(230, 60, 54, 12));
        lineEdit = new QLineEdit(TextBook);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        lineEdit->setGeometry(QRect(50, 60, 161, 20));
        fontComboBox = new QFontComboBox(TextBook);
        fontComboBox->setObjectName(QStringLiteral("fontComboBox"));
        fontComboBox->setGeometry(QRect(270, 60, 177, 22));
        textEdit = new QTextEdit(TextBook);
        textEdit->setObjectName(QStringLiteral("textEdit"));
        textEdit->setGeometry(QRect(10, 90, 431, 241));

        retranslateUi(TextBook);

        QMetaObject::connectSlotsByName(TextBook);
    } // setupUi

    void retranslateUi(QWidget *TextBook)
    {
        TextBook->setWindowTitle(QApplication::translate("TextBook", "Form", Q_NULLPTR));
        Weight->setText(QApplication::translate("TextBook", "\347\262\227\344\275\223", Q_NULLPTR));
        Italic->setText(QApplication::translate("TextBook", "\346\226\234\344\275\223", Q_NULLPTR));
        underLine->setText(QApplication::translate("TextBook", "\344\270\213\345\210\222\347\272\277", Q_NULLPTR));
        FortGroundColor->setText(QApplication::translate("TextBook", "\345\211\215\346\231\257\350\211\262", Q_NULLPTR));
        BackGroundColor->setText(QApplication::translate("TextBook", "\350\203\214\346\231\257\350\211\262", Q_NULLPTR));
        LB_FontSize->setText(QApplication::translate("TextBook", "\345\255\227\345\217\267\357\274\232", Q_NULLPTR));
        LB_Font->setText(QApplication::translate("TextBook", "\345\255\227\344\275\223\357\274\232", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class TextBook: public Ui_TextBook {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TEXTBOOK_H
