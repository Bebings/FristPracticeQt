/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QPushButton *monutButton;
    QPushButton *textButton;
    QPushButton *OpenHtml;
    QPushButton *calendar;
    QPushButton *ButtonTest;
    QPushButton *GetInfo;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QStringLiteral("Widget"));
        Widget->resize(386, 252);
        monutButton = new QPushButton(Widget);
        monutButton->setObjectName(QStringLiteral("monutButton"));
        monutButton->setGeometry(QRect(190, 10, 75, 23));
        textButton = new QPushButton(Widget);
        textButton->setObjectName(QStringLiteral("textButton"));
        textButton->setGeometry(QRect(280, 10, 75, 23));
        OpenHtml = new QPushButton(Widget);
        OpenHtml->setObjectName(QStringLiteral("OpenHtml"));
        OpenHtml->setGeometry(QRect(10, 40, 75, 23));
        calendar = new QPushButton(Widget);
        calendar->setObjectName(QStringLiteral("calendar"));
        calendar->setGeometry(QRect(100, 40, 75, 23));
        ButtonTest = new QPushButton(Widget);
        ButtonTest->setObjectName(QStringLiteral("ButtonTest"));
        ButtonTest->setGeometry(QRect(10, 10, 75, 23));
        GetInfo = new QPushButton(Widget);
        GetInfo->setObjectName(QStringLiteral("GetInfo"));
        GetInfo->setGeometry(QRect(100, 10, 75, 23));

        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QApplication::translate("Widget", "Widget", Q_NULLPTR));
        monutButton->setText(QApplication::translate("Widget", "\347\231\273\345\275\225\347\225\214\351\235\242", Q_NULLPTR));
        textButton->setText(QApplication::translate("Widget", "\346\226\207\346\234\254\347\225\214\351\235\242", Q_NULLPTR));
        OpenHtml->setText(QApplication::translate("Widget", "\346\265\217\350\247\210\345\231\250", Q_NULLPTR));
        calendar->setText(QApplication::translate("Widget", "\346\227\245\345\216\206", Q_NULLPTR));
        ButtonTest->setText(QApplication::translate("Widget", "\346\214\211\351\222\256\346\265\213\350\257\225", Q_NULLPTR));
        GetInfo->setText(QApplication::translate("Widget", "\344\277\241\346\201\257\346\224\266\351\233\206", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
