/********************************************************************************
** Form generated from reading UI file 'buttontest.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_BUTTONTEST_H
#define UI_BUTTONTEST_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ButtonTest
{
public:
    QPushButton *ConntButton;
    QLabel *label;
    QPushButton *DisconntButton;
    QPushButton *hungryButton;
    QLineEdit *lineEdit;
    QPushButton *pushButton;

    void setupUi(QWidget *ButtonTest)
    {
        if (ButtonTest->objectName().isEmpty())
            ButtonTest->setObjectName(QStringLiteral("ButtonTest"));
        ButtonTest->resize(200, 167);
        ConntButton = new QPushButton(ButtonTest);
        ConntButton->setObjectName(QStringLiteral("ConntButton"));
        ConntButton->setGeometry(QRect(10, 120, 75, 23));
        label = new QLabel(ButtonTest);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(10, 90, 161, 16));
        DisconntButton = new QPushButton(ButtonTest);
        DisconntButton->setObjectName(QStringLiteral("DisconntButton"));
        DisconntButton->setGeometry(QRect(100, 120, 75, 23));
        hungryButton = new QPushButton(ButtonTest);
        hungryButton->setObjectName(QStringLiteral("hungryButton"));
        hungryButton->setGeometry(QRect(100, 10, 75, 23));
        lineEdit = new QLineEdit(ButtonTest);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        lineEdit->setGeometry(QRect(10, 60, 161, 21));
        pushButton = new QPushButton(ButtonTest);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(10, 10, 75, 23));

        retranslateUi(ButtonTest);

        QMetaObject::connectSlotsByName(ButtonTest);
    } // setupUi

    void retranslateUi(QWidget *ButtonTest)
    {
        ButtonTest->setWindowTitle(QApplication::translate("ButtonTest", "Form", Q_NULLPTR));
        ConntButton->setText(QApplication::translate("ButtonTest", "\345\205\263\350\201\224", Q_NULLPTR));
        label->setText(QApplication::translate("ButtonTest", "Show input", Q_NULLPTR));
        DisconntButton->setText(QApplication::translate("ButtonTest", "\345\217\226\346\266\210\345\205\263\350\201\224", Q_NULLPTR));
        hungryButton->setText(QApplication::translate("ButtonTest", "\345\220\203\345\256\214\344\272\206\357\274\201", Q_NULLPTR));
        lineEdit->setText(QApplication::translate("ButtonTest", "User input", Q_NULLPTR));
        pushButton->setText(QApplication::translate("ButtonTest", "\346\210\221\351\245\277\344\272\206~", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class ButtonTest: public Ui_ButtonTest {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_BUTTONTEST_H
