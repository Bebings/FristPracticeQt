/********************************************************************************
** Form generated from reading UI file 'mount.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MOUNT_H
#define UI_MOUNT_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_mount
{
public:
    QLineEdit *UserName;
    QLabel *LB_UserName;
    QPushButton *Quit;
    QPushButton *Mount;
    QLineEdit *Password;
    QLabel *LB_Password;

    void setupUi(QWidget *mount)
    {
        if (mount->objectName().isEmpty())
            mount->setObjectName(QStringLiteral("mount"));
        mount->resize(332, 218);
        UserName = new QLineEdit(mount);
        UserName->setObjectName(QStringLiteral("UserName"));
        UserName->setGeometry(QRect(140, 50, 113, 20));
        LB_UserName = new QLabel(mount);
        LB_UserName->setObjectName(QStringLiteral("LB_UserName"));
        LB_UserName->setGeometry(QRect(80, 50, 54, 12));
        Quit = new QPushButton(mount);
        Quit->setObjectName(QStringLiteral("Quit"));
        Quit->setGeometry(QRect(180, 130, 75, 23));
        Mount = new QPushButton(mount);
        Mount->setObjectName(QStringLiteral("Mount"));
        Mount->setGeometry(QRect(70, 130, 75, 23));
        Password = new QLineEdit(mount);
        Password->setObjectName(QStringLiteral("Password"));
        Password->setGeometry(QRect(140, 80, 113, 20));
        LB_Password = new QLabel(mount);
        LB_Password->setObjectName(QStringLiteral("LB_Password"));
        LB_Password->setGeometry(QRect(90, 80, 54, 12));

        retranslateUi(mount);

        QMetaObject::connectSlotsByName(mount);
    } // setupUi

    void retranslateUi(QWidget *mount)
    {
        mount->setWindowTitle(QApplication::translate("mount", "Form", Q_NULLPTR));
        UserName->setText(QString());
        LB_UserName->setText(QApplication::translate("mount", "\347\224\250\346\210\267\345\220\215\357\274\232", Q_NULLPTR));
        Quit->setText(QApplication::translate("mount", "\351\200\200\345\207\272", Q_NULLPTR));
        Mount->setText(QApplication::translate("mount", "\347\231\273\345\275\225", Q_NULLPTR));
        LB_Password->setText(QApplication::translate("mount", "\345\257\206\347\240\201\357\274\232", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class mount: public Ui_mount {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MOUNT_H
