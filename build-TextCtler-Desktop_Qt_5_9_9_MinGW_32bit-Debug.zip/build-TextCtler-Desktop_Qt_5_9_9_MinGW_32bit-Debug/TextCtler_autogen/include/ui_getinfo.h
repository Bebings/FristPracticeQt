/********************************************************************************
** Form generated from reading UI file 'getinfo.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GETINFO_H
#define UI_GETINFO_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_GetInfo
{
public:
    QLabel *label_2;
    QRadioButton *radioButtonMan;
    QGroupBox *groupBox;
    QPushButton *pushButton;
    QRadioButton *Age0_14;
    QRadioButton *Age14_18;
    QRadioButton *Age18_24;
    QRadioButton *Age24_35;
    QRadioButton *radioButtonYellow;
    QLabel *label;
    QRadioButton *radioButtonGreen;
    QRadioButton *radioButtonWoman;
    QRadioButton *radioButtonRed;

    void setupUi(QWidget *GetInfo)
    {
        if (GetInfo->objectName().isEmpty())
            GetInfo->setObjectName(QStringLiteral("GetInfo"));
        GetInfo->resize(440, 260);
        label_2 = new QLabel(GetInfo);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(20, 40, 54, 12));
        radioButtonMan = new QRadioButton(GetInfo);
        radioButtonMan->setObjectName(QStringLiteral("radioButtonMan"));
        radioButtonMan->setGeometry(QRect(100, 10, 89, 16));
        groupBox = new QGroupBox(GetInfo);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        groupBox->setGeometry(QRect(10, 70, 411, 171));
        pushButton = new QPushButton(groupBox);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(320, 130, 75, 23));
        Age0_14 = new QRadioButton(groupBox);
        Age0_14->setObjectName(QStringLiteral("Age0_14"));
        Age0_14->setGeometry(QRect(50, 40, 89, 16));
        Age14_18 = new QRadioButton(groupBox);
        Age14_18->setObjectName(QStringLiteral("Age14_18"));
        Age14_18->setGeometry(QRect(50, 70, 89, 16));
        Age18_24 = new QRadioButton(groupBox);
        Age18_24->setObjectName(QStringLiteral("Age18_24"));
        Age18_24->setGeometry(QRect(50, 100, 89, 16));
        Age24_35 = new QRadioButton(groupBox);
        Age24_35->setObjectName(QStringLiteral("Age24_35"));
        Age24_35->setGeometry(QRect(50, 130, 89, 16));
        radioButtonYellow = new QRadioButton(GetInfo);
        radioButtonYellow->setObjectName(QStringLiteral("radioButtonYellow"));
        radioButtonYellow->setGeometry(QRect(210, 40, 89, 16));
        label = new QLabel(GetInfo);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(20, 10, 54, 12));
        radioButtonGreen = new QRadioButton(GetInfo);
        radioButtonGreen->setObjectName(QStringLiteral("radioButtonGreen"));
        radioButtonGreen->setGeometry(QRect(100, 40, 89, 16));
        radioButtonWoman = new QRadioButton(GetInfo);
        radioButtonWoman->setObjectName(QStringLiteral("radioButtonWoman"));
        radioButtonWoman->setGeometry(QRect(210, 10, 89, 16));
        radioButtonRed = new QRadioButton(GetInfo);
        radioButtonRed->setObjectName(QStringLiteral("radioButtonRed"));
        radioButtonRed->setGeometry(QRect(300, 40, 89, 16));

        retranslateUi(GetInfo);

        QMetaObject::connectSlotsByName(GetInfo);
    } // setupUi

    void retranslateUi(QWidget *GetInfo)
    {
        GetInfo->setWindowTitle(QApplication::translate("GetInfo", "Form", Q_NULLPTR));
        label_2->setText(QApplication::translate("GetInfo", "\347\212\266\346\200\201\357\274\232", Q_NULLPTR));
        radioButtonMan->setText(QApplication::translate("GetInfo", "\347\224\267", Q_NULLPTR));
        groupBox->setTitle(QApplication::translate("GetInfo", "\345\271\264\351\276\204\346\256\265", Q_NULLPTR));
        pushButton->setText(QApplication::translate("GetInfo", "\345\274\271\347\252\227\346\230\276\347\244\272", Q_NULLPTR));
        Age0_14->setText(QApplication::translate("GetInfo", "0-14", Q_NULLPTR));
        Age14_18->setText(QApplication::translate("GetInfo", "14-18", Q_NULLPTR));
        Age18_24->setText(QApplication::translate("GetInfo", "18-24", Q_NULLPTR));
        Age24_35->setText(QApplication::translate("GetInfo", "24-35", Q_NULLPTR));
        radioButtonYellow->setText(QApplication::translate("GetInfo", "\351\273\204\347\240\201", Q_NULLPTR));
        label->setText(QApplication::translate("GetInfo", "\346\200\247\345\210\253\357\274\232", Q_NULLPTR));
        radioButtonGreen->setText(QApplication::translate("GetInfo", "\347\273\277\347\240\201", Q_NULLPTR));
        radioButtonWoman->setText(QApplication::translate("GetInfo", "\345\245\263", Q_NULLPTR));
        radioButtonRed->setText(QApplication::translate("GetInfo", "\347\272\242\347\240\201", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class GetInfo: public Ui_GetInfo {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GETINFO_H
