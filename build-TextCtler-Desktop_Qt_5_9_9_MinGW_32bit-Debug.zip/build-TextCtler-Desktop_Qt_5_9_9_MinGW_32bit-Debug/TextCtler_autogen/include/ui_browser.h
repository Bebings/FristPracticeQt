/********************************************************************************
** Form generated from reading UI file 'browser.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_BROWSER_H
#define UI_BROWSER_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Browser
{
public:
    QVBoxLayout *verticalLayout;
    QSplitter *splitter_2;
    QSplitter *splitter;
    QTextBrowser *textBrowser;
    QPlainTextEdit *plainTextEdit;
    QWidget *widget;
    QHBoxLayout *horizontalLayout;
    QPushButton *pushButtonForeward;
    QPushButton *pushButtonBack;
    QSpacerItem *horizontalSpacer;
    QPushButton *pushButtonOpen;

    void setupUi(QWidget *Browser)
    {
        if (Browser->objectName().isEmpty())
            Browser->setObjectName(QStringLiteral("Browser"));
        Browser->resize(542, 250);
        verticalLayout = new QVBoxLayout(Browser);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        splitter_2 = new QSplitter(Browser);
        splitter_2->setObjectName(QStringLiteral("splitter_2"));
        splitter_2->setStyleSheet(QLatin1String("QSplitter::handle {    \n"
"    background-color: rgb(255, 255, 255);\n"
"}"));
        splitter_2->setOrientation(Qt::Vertical);
        splitter = new QSplitter(splitter_2);
        splitter->setObjectName(QStringLiteral("splitter"));
        splitter->setStyleSheet(QLatin1String("QSplitter::handle {    \n"
"    background-color: rgb(255, 255, 255);\n"
"}"));
        splitter->setOrientation(Qt::Horizontal);
        textBrowser = new QTextBrowser(splitter);
        textBrowser->setObjectName(QStringLiteral("textBrowser"));
        splitter->addWidget(textBrowser);
        plainTextEdit = new QPlainTextEdit(splitter);
        plainTextEdit->setObjectName(QStringLiteral("plainTextEdit"));
        splitter->addWidget(plainTextEdit);
        splitter_2->addWidget(splitter);
        widget = new QWidget(splitter_2);
        widget->setObjectName(QStringLiteral("widget"));
        horizontalLayout = new QHBoxLayout(widget);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        pushButtonForeward = new QPushButton(widget);
        pushButtonForeward->setObjectName(QStringLiteral("pushButtonForeward"));

        horizontalLayout->addWidget(pushButtonForeward);

        pushButtonBack = new QPushButton(widget);
        pushButtonBack->setObjectName(QStringLiteral("pushButtonBack"));

        horizontalLayout->addWidget(pushButtonBack);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        pushButtonOpen = new QPushButton(widget);
        pushButtonOpen->setObjectName(QStringLiteral("pushButtonOpen"));

        horizontalLayout->addWidget(pushButtonOpen);

        splitter_2->addWidget(widget);

        verticalLayout->addWidget(splitter_2);


        retranslateUi(Browser);

        QMetaObject::connectSlotsByName(Browser);
    } // setupUi

    void retranslateUi(QWidget *Browser)
    {
        Browser->setWindowTitle(QApplication::translate("Browser", "Form", Q_NULLPTR));
        pushButtonForeward->setText(QApplication::translate("Browser", "\345\211\215\350\277\233", Q_NULLPTR));
        pushButtonBack->setText(QApplication::translate("Browser", "\345\220\216\351\200\200", Q_NULLPTR));
        pushButtonOpen->setText(QApplication::translate("Browser", "\346\211\223\345\274\200html", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Browser: public Ui_Browser {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_BROWSER_H
